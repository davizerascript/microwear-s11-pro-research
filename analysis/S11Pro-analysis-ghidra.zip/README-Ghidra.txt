Projeto Ghidra S11 Pro

Requisitos: Ghidra 12.2, JDK 25 e a linguagem pi32v2 do plugin comunitário ghidra-jieli. Extraia S11Pro-analysis.gpr e a pasta S11Pro-analysis.rep para o mesmo diretório e abra o arquivo .gpr no Ghidra.

O programa importado é app.bin como raw binary, linguagem pi32v2, base provisória 0x0. A função de entrada em offset zero foi marcada provisoriamente. A autoanálise detectou 1.186 funções e 40.795 objetos de instrução, mas existem conflitos de decodificação/erros P-code e as referências aos nomes de drivers não foram resolvidas. Não trate endereços absolutos, contagens ou decompilação como definitivos.
